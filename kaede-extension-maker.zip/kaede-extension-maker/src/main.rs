use std::env;
use std::fs::{self, File};
use std::io::Write;
use std::path::Path;
use serde::{Deserialize, Serialize};
use serde_json::{from_str, to_string_pretty};
use subprocess::{Exec, Redirection};

#[derive(Serialize, Deserialize, Debug)]
struct PackageData {
    name: String,
    version: String,
    author: String,
    description: Option<String>,
    dependencies: Vec<String>,
    custom_dependencies: Vec<String>,
    language: String,
}

fn main() -> Result<(), Box<dyn std::error::Error>> {
    // 1. Parse arguments
    let args: Vec<String> = env::args().collect();

    if args.len() < 2 {
        println!("Usage: kaede-extension-maker <package_dir> [--release | --dev | --build]");
        return Ok(());
    }

    let package_dir = &args[1];
    let _mode = if args.len() > 2 {
        &args[2]
    } else {
        "--build" // Default to build mode
    };

    // 2. Read package.data
    let package_data_path = Path::new(package_dir).join("package.data");
    let package_data = match fs::read_to_string(&package_data_path) {
        Ok(data) => from_str::<PackageData>(&data)?,
        Err(_) => {
            eprintln!("Error: package.data file not found or invalid.");
            std::process::exit(1);
        }
    };

    // 3. Create the .extension file
    let output_file = format!("{}.extension", package_data.name);
    let output_path = Path::new(package_dir).join(&output_file);
    let mut file = File::create(&output_path)?;

    // 4. Write package.data
    let package_data_json = to_string_pretty(&package_data)?;
    writeln!(file, "package_data: {}", package_data_json)?;

    // 5. Install PIP dependencies
    if !package_data.dependencies.is_empty() {
        fs::create_dir_all(Path::new(package_dir).join("dependencies"))?;

        let deps_path = Path::new(package_dir).join("dependencies").to_str().unwrap().to_owned();
        let output = Exec::cmd("pip")
            .args(&["install", "-t", &deps_path])
            .args(&package_data.dependencies)
            .stdout(Redirection::Pipe)
            .stderr(Redirection::Merge)
            .capture()?;

        if output.success() {
            println!("Installed PIP dependencies successfully.");
        } else {
            eprintln!("Error installing PIP dependencies: {}", String::from_utf8_lossy(&output.stderr));
        }
    }

    // 6. Handle custom dependencies
    for custom_dependency in package_data.custom_dependencies {
        let source_path = Path::new(package_dir).join(&custom_dependency);
        let target_path = Path::new(package_dir).join("dependencies").join(&custom_dependency);
        if source_path.exists() {
            if let Err(e) = fs::copy(source_path, target_path) {
                eprintln!("Error: Copying custom dependency '{}' failed: {}", custom_dependency, e);
                continue;
            }
            println!("Added custom dependency: {}", custom_dependency);
        } else {
            eprintln!("Error: Custom dependency file not found: {}", custom_dependency);
        }
    }

    // 7. Write package code
    let package_code_path = Path::new(package_dir).join("package").join(format!("{}.{}", package_data.name, package_data.language));
    if package_code_path.exists() {
        let package_code = fs::read_to_string(&package_code_path)?;
        writeln!(file, "package_code: {}", package_code)?;
    } else {
        eprintln!("Error: Package code file not found: {}", package_code_path.display());
        std::process::exit(1);
    }

    println!("Extension package created: {}", output_file);
    Ok(())
}
